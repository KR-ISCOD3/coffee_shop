<header class="navbar p-2 px-4 bg-body">
    <h3 class="m-0 text-secondary">Welcome to P-COFFEE</h3>
    <div class="navbar">
     <div style="width: 40px;height: 40px;" class="rounded-circle overflow-hidden ">
         <img src="{{asset('user.png')}}" alt="" class="object-fit-cover w-100 h-100">
     </div>
     <div style="line-height: 18px;">
         <p class="m-0 ms-2 fw-medium">Mr.John</p>
         <p class="m-0 ms-2 text-secondary">Service</p>
     </div>
    </div>
 </header>

